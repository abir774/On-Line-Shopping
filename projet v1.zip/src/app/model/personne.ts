export class Personne {
  

    constructor(public id:number, public prenom:string, 
        public nom:string, public age:number, public metier:string, 
        public path:string) {
       
    }

}